----  
<h1><b>Meridian Library</b></h1>
----  
##1 Meridian Libraryとは
  
Meridian をTeesy4.0, ESP32などで使うための共通のライブラリ関数です。  

  
##2 Meridian.h の導入方法  
ほにゃらら（後で更新）  


##3 ライブラリの使い方  
基本的な使い方は、Meridian TWIN, Meridian -LITE-のコードとして公開しています。  
ほにゃらら（後でURL）  

各関数についての使用方法などについては、Meridian.hのヘッダーファイルの他、  
当サイトにも掲載しています。  
左の「Library Function」メニューより、各関数名をご参照ください。  